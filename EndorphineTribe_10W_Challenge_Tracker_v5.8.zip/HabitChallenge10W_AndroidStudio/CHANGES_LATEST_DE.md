# Letzte Änderungen

- Startdatum wird in der Übersicht nicht mehr angezeigt.
- Setup ist übersichtlicher: Startdatum, Tribe Sync und jedes Habit mit Wochenziel stehen jeweils in eigenen Karten/Feldern.
- Tribe-Sync-Einstellungen wurden aus dem Einstellungsmenü entfernt, weil sie über `Setup bearbeiten` erreichbar sind.
- Standard-Sichtbarkeit im Tribe Sync bleibt: `Habit-Details für heute anzeigen`.
