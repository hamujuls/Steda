package at.habitchallenge.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ClipDrawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collections;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends Activity {
    private static final int HABITS = 10;
    private static final int DAYS = 70;
    private static final int WEEKS = 10;
    private static final int REQ_EXPORT = 1001;
    private static final int REQ_IMPORT = 1002;

    private static final String SECTION_OVERVIEW = "overview";
    private static final String SECTION_TRACK = "track";
    private static final String SECTION_WEEKLY = "weekly";
    private static final String SECTION_REFLECTION = "reflection";
    private static final String SECTION_TRIBE = "tribe";
    private static final String SECTION_CHAT = "chat";
    private static final String SECTION_SETTINGS = "settings";
    private static final String SECTION_SETUP = "setup";

    private final SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy", Locale.GERMANY);
    private HabitData data;
    private FrameLayout root;
    private LinearLayout content;
    private ScrollView mainScroll;
    private View chatComposerView;
    private HorizontalScrollView navScrollView;
    private int navScrollX = 0;
    private float tribePullStartY = -1f;
    private String currentSection = SECTION_OVERVIEW;
    private int selectedWeek = 0;
    private int setupVisibleHabitCount = 2;
    private EditText[] setupHabitFields;
    private Spinner[] setupTargetSpinners;
    private EditText setupDisplayNameField;
    private EditText setupGroupCodeField;
    private Spinner setupPrivacySpinner;
    private SharedPreferences prefs;
    private FirebaseAuth auth;
    private FirebaseFirestore firestore;
    private ListenerRegistration tribeRegistration;
    private ListenerRegistration chatRegistration;
    private final ArrayList<TribeMember> tribeMembers = new ArrayList<>();
    private final ArrayList<ChatMessage> chatMessages = new ArrayList<>();
    private String firebaseStatus = "Firebase nicht eingerichtet";
    private String listeningGroup = "";
    private String listeningChatGroup = "";
    private final Handler syncHandler = new Handler(Looper.getMainLooper());
    private final Runnable autoSyncRunnable = new Runnable() {
        @Override public void run() {
            if (data != null && data.configured && data.syncEnabled) {
                ensureSignedInAndSync(false);
            }
            syncHandler.postDelayed(this, 30000L);
        }
    };

    private final int bg = Color.rgb(11, 13, 16);
    private final int ink = Color.rgb(245, 247, 250);
    private final int muted = Color.rgb(152, 162, 174);
    private final int green = Color.rgb(76, 187, 121);
    private final int red = Color.rgb(214, 101, 101);
    private final int yellow = Color.rgb(212, 173, 88);
    private final int blue = Color.rgb(103, 127, 214);
    private final int darkBlue = Color.rgb(45, 58, 95);
    private final int cardBg = Color.rgb(20, 24, 30);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("endorphine_tribe_10w_v2", Context.MODE_PRIVATE);
        data = HabitData.fromJson(prefs.getString("data", null));
        setupFirebase();
        selectedWeek = getCurrentWeek();
        if (!data.configured || activeHabitCount() == 0) {
            showSetup(false);
        } else {
            if (data.syncEnabled) ensureSignedInAndSync(false);
            showMainSection(SECTION_OVERVIEW);
        }
        startAutoSync();
    }

    private void startAutoSync() {
        syncHandler.removeCallbacks(autoSyncRunnable);
        syncHandler.postDelayed(autoSyncRunnable, 30000L);
    }

    @Override
    protected void onDestroy() {
        syncHandler.removeCallbacks(autoSyncRunnable);
        stopTribeListener();
        stopChatListener();
        super.onDestroy();
    }

    private void showMainSection(String section) {
        currentSection = section;
        buildShell(true, false);
        if (SECTION_OVERVIEW.equals(section)) renderOverview();
        else if (SECTION_TRACK.equals(section)) renderTrack();
        else if (SECTION_WEEKLY.equals(section)) renderWeekly();
        else if (SECTION_TRIBE.equals(section)) renderTribe();
        else if (SECTION_CHAT.equals(section)) renderChat();
        else renderReflection();
        animateSectionTransition();
    }

    private void showSettings() {
        currentSection = SECTION_SETTINGS;
        buildShell(true, false);
        renderSettings();
        animateSectionTransition();
    }

    private void showSetup(boolean fromSettings) {
        currentSection = SECTION_SETUP;
        setupVisibleHabitCount = clamp(Math.max(2, activeHabitCount()), 2, HABITS);
        buildShell(false, fromSettings && data.configured);
        renderSetup(fromSettings);
        animateSectionTransition();
    }

    private void buildShell(boolean showNav, boolean showGear) {
        root = new FrameLayout(this);
        root.setBackgroundColor(bg);
        root.setFitsSystemWindows(true);

        ScrollView scroll = new ScrollView(this);
        mainScroll = scroll;
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        int headerSpace = showNav ? dp(86) : dp(18);
        content.setPadding(dp(14), headerSpace, dp(14), dp(24));
        scroll.addView(content, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        scroll.setOnTouchListener((v, event) -> {
            if (!SECTION_TRIBE.equals(currentSection)) return false;
            if (event.getAction() == MotionEvent.ACTION_DOWN && scroll.getScrollY() == 0) {
                tribePullStartY = event.getY();
            } else if (event.getAction() == MotionEvent.ACTION_UP || event.getAction() == MotionEvent.ACTION_CANCEL) {
                if (tribePullStartY >= 0 && scroll.getScrollY() == 0 && event.getY() - tribePullStartY > dp(80)) {
                    toast("Teilnehmer werden aktualisiert …");
                    ensureSignedInAndSync(false);
                }
                tribePullStartY = -1f;
            }
            return false;
        });
        root.addView(scroll, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout headerShell = new LinearLayout(this);
        headerShell.setOrientation(LinearLayout.VERTICAL);
        headerShell.setPadding(0, dp(10), 0, 0);
        headerShell.setBackground(headerBackground());
        headerShell.setElevation(dp(4));

        FrameLayout.LayoutParams shellLp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        shellLp.setMargins(0, 0, 0, 0);
        headerShell.setLayoutParams(shellLp);

        if (showNav) {
            FrameLayout navContainer = new FrameLayout(this);
            LinearLayout.LayoutParams nclp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            navContainer.setLayoutParams(nclp);

            HorizontalScrollView navScroll = new HorizontalScrollView(this);
            navScrollView = navScroll;
            navScroll.setHorizontalScrollBarEnabled(false);
            navScroll.setPadding(0, 0, 0, 0);
            navScroll.setOverScrollMode(View.OVER_SCROLL_NEVER);
            navScroll.setClipToPadding(false);
            navScroll.setOnScrollChangeListener((v, scrollX, scrollY, oldScrollX, oldScrollY) -> navScrollX = scrollX);

            LinearLayout nav = new LinearLayout(this);
            nav.setOrientation(LinearLayout.HORIZONTAL);
            nav.setPadding(dp(8), 0, dp(8), 0);
            nav.addView(navButton("◈ Übersicht", SECTION_OVERVIEW));
            nav.addView(navButton("◎ Tracken", SECTION_TRACK));
            nav.addView(navButton("◔ Wochen", SECTION_WEEKLY));
            nav.addView(navButton("✎ Reflexion", SECTION_REFLECTION));
            nav.addView(navButton("◌ Tribe", SECTION_TRIBE));
            nav.addView(navButton("✉ Chat", SECTION_CHAT));
            nav.addView(navButton("⚙ Einstellungen", SECTION_SETTINGS));
            navScroll.addView(nav);
            navContainer.addView(navScroll, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            navScroll.post(() -> centerSelectedNav(navScroll, nav));

            View leftFade = new View(this);
            leftFade.setBackground(edgeFadeLeft());
            FrameLayout.LayoutParams lfp = new FrameLayout.LayoutParams(dp(34), dp(46));
            lfp.gravity = Gravity.START | Gravity.CENTER_VERTICAL;
            navContainer.addView(leftFade, lfp);

            View rightFade = new View(this);
            rightFade.setBackground(edgeFadeRight());
            FrameLayout.LayoutParams rfp = new FrameLayout.LayoutParams(dp(34), dp(46));
            rfp.gravity = Gravity.END | Gravity.CENTER_VERTICAL;
            navContainer.addView(rightFade, rfp);

            headerShell.addView(navContainer);
        }

        if (showNav) {
            View headerDivider = new View(this);
            LinearLayout.LayoutParams dividerLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1));
            dividerLp.setMargins(0, dp(8), 0, 0);
            headerDivider.setBackgroundColor(Color.argb(70, 255, 255, 255));
            headerShell.addView(headerDivider, dividerLp);
            root.addView(headerShell);
        }
        setContentView(root);
    }

    private void centerSelectedNav(HorizontalScrollView navScroll, LinearLayout nav) {
        if (navScroll == null || nav == null) return;
        for (int i = 0; i < nav.getChildCount(); i++) {
            View child = nav.getChildAt(i);
            Object tag = child.getTag();
            if (tag != null && tag.equals(currentSection)) {
                int target = child.getLeft() - (navScroll.getWidth() - child.getWidth()) / 2;
                navScroll.smoothScrollTo(Math.max(0, target), 0);
                navScrollX = Math.max(0, target);
                return;
            }
        }
    }

    private Button navButton(String label, String section) {
        Button b = new Button(this);
        b.setTag(section);
        b.setText(label);
        b.setAllCaps(false);
        boolean active = section.equals(currentSection);
        b.setTextSize(active ? 17 : 15);
        b.setTextColor(active ? Color.WHITE : Color.rgb(228, 232, 237));
        b.setTypeface(active ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        b.setBackground(tabBackground(active));
        b.setPadding(dp(active ? 22 : 20), 0, dp(active ? 22 : 20), 0);
        b.setLetterSpacing(active ? 0.01f : 0f);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(active ? 52 : 46));
        lp.setMargins(0, dp(active ? -1 : 2), dp(8), 0);
        b.setLayoutParams(lp);
        b.setElevation(active ? dp(3) : dp(1));
        b.setOnClickListener(v -> {
            if (navScrollView != null) navScrollX = navScrollView.getScrollX();
            if (SECTION_SETTINGS.equals(currentSection) && !SECTION_SETTINGS.equals(section)) {
                autosaveSetupDraft(true);
            }
            if (SECTION_SETTINGS.equals(section)) showSettings();
            else showMainSection(section);
        });
        return b;
    }

    private void clearContent() {
        content.removeAllViews();
    }

    private TextView sectionBadge(String text) {
        TextView t = pillText(text, Color.rgb(44, 50, 60));
        t.setTextColor(Color.rgb(224, 229, 235));
        return t;
    }

    private void renderOverview() {
        clearContent();

        LinearLayout hero = heroCard();
        hero.addView(smallCaps("Challenge Dashboard"));
        LinearLayout heroTop = new LinearLayout(this);
        heroTop.setOrientation(LinearLayout.HORIZONTAL);
        heroTop.setGravity(Gravity.CENTER_VERTICAL);
        heroTop.setPadding(0, dp(8), 0, 0);

        LinearLayout heroLeft = new LinearLayout(this);
        heroLeft.setOrientation(LinearLayout.VERTICAL);
        TextView heroTitle = new TextView(this);
        heroTitle.setText("Woche " + (getCurrentWeek() + 1) + " von 10");
        heroTitle.setTextColor(ink);
        heroTitle.setTypeface(Typeface.DEFAULT_BOLD);
        heroTitle.setTextSize(30);
        heroLeft.addView(heroTitle);
        TextView heroSub = smallText("Fokus auf Konstanz, Rhythmus und kleine tägliche Schritte.");
        heroSub.setTextColor(Color.rgb(214, 222, 230));
        heroLeft.addView(heroSub);
        heroTop.addView(heroLeft, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        heroTop.addView(circleStat(percentInt(totalDone(), totalDenom()) + "%", "Gesamt"));
        hero.addView(heroTop);

        LinearLayout statsGrid = new LinearLayout(this);
        statsGrid.setOrientation(LinearLayout.HORIZONTAL);
        statsGrid.setPadding(0, dp(16), 0, 0);
        statsGrid.addView(metricPill("Heute", dayDone(dayIndexForToday()) + " / " + Math.max(1, dayDenom(dayIndexForToday()))), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        statsGrid.addView(space(dp(8)), new LinearLayout.LayoutParams(dp(8), 1));
        statsGrid.addView(metricPill("Streak", getStreak() + " Tage"), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        statsGrid.addView(space(dp(8)), new LinearLayout.LayoutParams(dp(8), 1));
        statsGrid.addView(metricPill("Wochenziele", weekGoalsReached(getCurrentWeek()) + " / " + activeHabitCount()), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        hero.addView(statsGrid);

        ProgressBar pb = progressBar(100, percentInt(totalDone(), totalDenom()), green);
        LinearLayout.LayoutParams pblp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(10));
        pblp.setMargins(0, dp(16), 0, 0);
        hero.addView(pb, pblp);
        addView(hero);

        addSubsectionTitle("10-Wochen Heatmap");
        LinearLayout heat = card();
        heat.addView(label("Dein Verlauf auf einen Blick"));
        heat.addView(smallText("Grün = stark, Gelb = teilweise, Rot = nicht geschafft, Grau = leer."));
        for (int w = 0; w < WEEKS; w++) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            TextView weekTag = smallCaps("W" + (w + 1));
            LinearLayout.LayoutParams wlp = new LinearLayout.LayoutParams(dp(28), ViewGroup.LayoutParams.WRAP_CONTENT);
            row.addView(weekTag, wlp);
            for (int i = 0; i < 7; i++) {
                int d = w * 7 + i;
                View cell = new View(this);
                GradientDrawable gd = new GradientDrawable();
                gd.setColor(dayHeatColor(d));
                gd.setCornerRadius(dp(5));
                gd.setStroke(dp(1), Color.argb(35, 255, 255, 255));
                cell.setBackground(gd);
                LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(dp(18), dp(18));
                clp.setMargins(0, dp(2), dp(6), dp(2));
                row.addView(cell, clp);
            }
            heat.addView(row);
        }
        addView(heat);

        addSubsectionTitle("Wochenfortschritt");
        for (int w = 0; w < WEEKS; w++) {
            LinearLayout row = card();
            row.addView(label("Woche " + (w + 1)));
            row.addView(smallText(formatDate(getDateForDay(w * 7)) + " – " + formatDate(getDateForDay(w * 7 + 6))));
            int done = weekDone(w);
            int denom = weekDenom(w);
            TextView percent = bigValue(percentText(done, denom));
            percent.setPadding(0, dp(6), 0, 0);
            row.addView(percent);
            row.addView(smallText("Erreichte Habit-Ziele: " + weekGoalsReached(w) + " / " + activeHabitCount()));
            ProgressBar wp = progressBar(100, percentInt(done, denom), w == getCurrentWeek() ? green : blue);
            LinearLayout.LayoutParams wlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(8));
            wlp.setMargins(0, dp(10), 0, 0);
            row.addView(wp, wlp);
            addView(row);
        }
    }

    private void renderSetup(boolean fromSettings) {
        clearContent();
        addSectionTitle(fromSettings ? "Setup bearbeiten" : "Setup");

        renderSetupFields(fromSettings, false);

        LinearLayout actionCard = card();
        if (fromSettings) {
            Button back = neutralButton("Zurück zu den Einstellungen");
            back.setOnClickListener(v -> {
                autosaveSetupDraft(true);
                showSettings();
            });
            actionCard.addView(back);
        } else {
            Button save = primaryButton("Setup abschließen");
            save.setOnClickListener(v -> {
                autosaveSetupDraft(false);
                if (activeHabitCount() == 0) {
                    toast("Bitte mindestens ein Habit eintragen.");
                    return;
                }
                data.configured = true;
                saveData();
                if (data.syncEnabled) ensureSignedInAndSync(false);
                selectedWeek = getCurrentWeek();
                toast("Setup abgeschlossen");
                showMainSection(SECTION_OVERVIEW);
            });
            actionCard.addView(save);
        }
        addView(actionCard);
    }

    private void renderSetupFields(boolean fromSettings, boolean embeddedInSettings) {
        LinearLayout intro = card();
        intro.addView(label(fromSettings ? "Passe Challenge, Habits und Tribe Sync an" : "Willkommen zur 10-Wochen-Challenge"));
        intro.addView(smallText(fromSettings
                ? "Hier kannst du Startdatum, Habits, Wochenziele und Tribe Sync ändern. In der normalen Ansicht werden nur aktive Habits angezeigt."
                : "Bitte richte die App beim ersten Start einmal ein. Danach siehst du in der normalen Ansicht nur noch deine eingestellten Habits."));
        addView(intro);

        LinearLayout dateCard = card();
        dateCard.addView(label("Startdatum"));
        Button date = primaryButton("Startdatum wählen: " + formatDate(data.startDateMillis));
        date.setOnClickListener(v -> pickStartDate(() -> {
            if (embeddedInSettings) renderSettings();
            else {
                buildShell(false, fromSettings && data.configured);
                renderSetup(fromSettings);
            }
        }));
        dateCard.addView(date);
        addView(dateCard);

        LinearLayout syncCard = card();
        syncCard.addView(label("Tribe Sync (optional)"));
        syncCard.addView(smallText("Wenn du Name und Gruppen-Code einträgst, kann die App deine Fortschritte mit der Gruppe synchronisieren."));
        syncCard.addView(label("Name in der Gruppe"));
        EditText displayNameField = edit(data.displayName, "z.B. Ju");
        setupDisplayNameField = displayNameField;
        syncCard.addView(displayNameField);
        syncCard.addView(label("Gruppen-Code"));
        EditText groupCodeField = edit(data.groupCode, "z.B. endorphine-tribe-10w");
        setupGroupCodeField = groupCodeField;
        groupCodeField.setSingleLine(true);
        syncCard.addView(groupCodeField);
        syncCard.addView(label("Sichtbarkeit"));
        Spinner privacySpinner = privacySpinner(data.privacyMode);
        setupPrivacySpinner = privacySpinner;
        syncCard.addView(privacySpinner);
        addView(syncCard);

        EditText[] habitFields = new EditText[HABITS];
        Spinner[] targetSpinners = new Spinner[HABITS];
        setupHabitFields = habitFields;
        setupTargetSpinners = targetSpinners;
        int visibleCount = clamp(setupVisibleHabitCount, 2, HABITS);
        for (int i = 0; i < visibleCount; i++) {
            LinearLayout habitCard = card();
            habitCard.addView(label("Habit " + (i + 1)));
            EditText h = edit(data.habitNames[i], "z.B. Krafttraining, Laufen, Mobility ...");
            habitFields[i] = h;
            habitCard.addView(h);

            habitCard.addView(label("Wie oft pro Woche"));
            Spinner t = targetSpinner(data.targets[i]);
            targetSpinners[i] = t;
            habitCard.addView(t);
            habitCard.addView(smallText("Leer lassen, wenn du dieses Habit nicht nutzen möchtest."));
            addView(habitCard);
        }

        if (visibleCount < HABITS) {
            LinearLayout addHabitCard = card();
            Button addHabit = neutralButton("+ Habit hinzufügen");
            addHabit.setOnClickListener(v -> {
                for (int i = 0; i < visibleCount; i++) {
                    data.habitNames[i] = habitFields[i].getText().toString().trim();
                    data.targets[i] = targetSpinners[i].getSelectedItemPosition();
                }
                setupVisibleHabitCount = clamp(setupVisibleHabitCount + 1, 2, HABITS);
                if (embeddedInSettings) renderSettings();
                else renderSetup(fromSettings);
            });
            addHabitCard.addView(addHabit);
            addView(addHabitCard);
        }

    }

    private void autosaveSetupDraft(boolean markConfigured) {
        if (setupHabitFields != null && setupTargetSpinners != null) {
            for (int i = 0; i < HABITS; i++) {
                if (setupHabitFields[i] != null) {
                    data.habitNames[i] = setupHabitFields[i].getText().toString().trim();
                    data.targets[i] = setupTargetSpinners[i].getSelectedItemPosition();
                }
            }
        }
        if (setupDisplayNameField != null) data.displayName = setupDisplayNameField.getText().toString().trim();
        if (setupGroupCodeField != null) data.groupCode = setupGroupCodeField.getText().toString().trim();
        if (setupPrivacySpinner != null) data.privacyMode = setupPrivacySpinner.getSelectedItemPosition();
        data.syncEnabled = !data.displayName.isEmpty() && !data.groupCode.isEmpty();
        if (markConfigured) data.configured = true;
        saveData();
        if (data.syncEnabled) ensureSignedInAndSync(false);
    }

    @Override
    public void onBackPressed() {
        if (SECTION_SETUP.equals(currentSection) && data != null && data.configured) {
            autosaveSetupDraft(true);
            showSettings();
            return;
        }
        if (SECTION_SETTINGS.equals(currentSection)) {
            autosaveSetupDraft(true);
        }
        super.onBackPressed();
    }

    private void renderTrack() {
        clearContent();
        
        content.addView(smallText("Status kannst du direkt über die drei Auswahl-Chips setzen."));
        content.addView(compactWeekSpinner("Woche auswählen", selectedWeek, pos -> {
            selectedWeek = pos;
            renderTrack();
        }));

        ArrayList<Integer> days = new ArrayList<>();
        for (int d = selectedWeek * 7; d < selectedWeek * 7 + 7; d++) days.add(d);
        int today = dayIndexForToday();
        if (selectedWeek == getCurrentWeek() && days.contains(today)) {
            days.remove(Integer.valueOf(today));
            days.add(0, today);
        }

        for (int d : days) {
            boolean isToday = d == today;
            LinearLayout dayCard = isToday ? heroCard() : card();
            if (isToday) dayCard.addView(smallCaps("Heute"));

            LinearLayout dayTop = new LinearLayout(this);
            dayTop.setOrientation(LinearLayout.HORIZONTAL);
            dayTop.setGravity(Gravity.CENTER_VERTICAL);
            TextView dayLabel = label("Tag " + (d + 1) + " · " + formatDate(getDateForDay(d)));
            dayLabel.setPadding(0, 0, 0, 0);
            dayTop.addView(dayLabel, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            int dayDone = dayDone(d);
            int dayDenom = dayDenom(d);
            dayTop.addView(sectionBadge(percentText(dayDone, dayDenom)));
            dayCard.addView(dayTop);
            dayCard.addView(smallText(isToday ? "Aktueller Tag" : "Tagesquote"));
            ProgressBar dpb = progressBar(Math.max(1, activeHabitCount()), Math.min(dayDone, Math.max(1, activeHabitCount())), isToday ? green : blue);
            LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(6));
            dlp.setMargins(0, dp(8), 0, dp(4));
            dayCard.addView(dpb, dlp);

            for (int h = 0; h < HABITS; h++) {
                if (!isHabitActive(h)) continue;
                int dayIndex = d;
                int habitIndex = h;
                LinearLayout row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(dp(12), dp(12), dp(12), dp(12));
                row.setBackground(subCardBackground());
                LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                rlp.setMargins(0, dp(10), 0, 0);
                row.setLayoutParams(rlp);

                LinearLayout left = new LinearLayout(this);
                left.setOrientation(LinearLayout.VERTICAL);
                TextView habitName = label(data.habitNames[h]);
                habitName.setPadding(0, 0, 0, 0);
                left.addView(habitName);
                left.addView(smallText("Ziel: " + data.targets[h] + "× pro Woche"));
                row.addView(left, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

                LinearLayout selector = stateSelector(data.states[d][h], newState -> {
                    if (data.states[dayIndex][habitIndex] == newState) data.states[dayIndex][habitIndex] = 0;
                    else data.states[dayIndex][habitIndex] = newState;
                    saveData();
                    renderTrack();
                });
                row.addView(selector);
                dayCard.addView(row);
            }
            addView(dayCard);
        }
    }

    private void renderWeekly() {
        clearContent();
        
        content.addView(compactWeekSpinner("Woche auswählen", selectedWeek, pos -> {
            selectedWeek = pos;
            renderWeekly();
        }));

        LinearLayout summary = heroCard();
        summary.addView(smallCaps("Wochenfokus"));
        TextView wkLabel = label("Woche " + (selectedWeek + 1));
        wkLabel.setTextSize(24);
        summary.addView(wkLabel);
        summary.addView(smallText(formatDate(getDateForDay(selectedWeek * 7)) + " – " + formatDate(getDateForDay(selectedWeek * 7 + 6))));
        TextView weeklyPercent = bigValue(percentText(weekDone(selectedWeek), weekDenom(selectedWeek)));
        weeklyPercent.setPadding(0, dp(8), 0, 0);
        summary.addView(weeklyPercent);
        summary.addView(smallText("Wochenziele erreicht: " + weekGoalsReached(selectedWeek) + " / " + activeHabitCount()));
        ProgressBar wp = progressBar(100, percentInt(weekDone(selectedWeek), weekDenom(selectedWeek)), green);
        LinearLayout.LayoutParams wpl = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(10));
        wpl.setMargins(0, dp(12), 0, 0);
        summary.addView(wp, wpl);
        addView(summary);

        for (int h = 0; h < HABITS; h++) {
            if (!isHabitActive(h)) continue;
            int done = habitWeekDone(selectedWeek, h);
            int denom = habitWeekDenom(selectedWeek, h);
            boolean reached = data.targets[h] <= 0 || done >= data.targets[h];
            boolean fullyRated = habitWeekFullyRated(selectedWeek, h);
            boolean allX = habitWeekAllX(selectedWeek, h);
            int statusColor;
            String statusText;
            if (reached) {
                statusColor = green;
                statusText = "Wochenziel erreicht";
            } else if (fullyRated && allX) {
                statusColor = red;
                statusText = "Wochenziel nicht erreicht";
            } else if (fullyRated) {
                statusColor = yellow;
                statusText = "Wochenziel nur teilweise erreicht";
            } else {
                statusColor = blue;
                statusText = "Noch offen";
            }
            LinearLayout row = card();
            row.addView(label(data.habitNames[h]));
            row.addView(smallText("Geschafft: " + done + " / " + data.targets[h] + " · Quote: " + percentText(done, denom)));
            ProgressBar hp = progressBar(Math.max(1, data.targets[h]), Math.min(done, Math.max(1, data.targets[h])), statusColor);
            LinearLayout.LayoutParams hlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(8));
            hlp.setMargins(0, dp(10), 0, 0);
            row.addView(hp, hlp);
            TextView status = pillText(statusText, statusColor);
            LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            slp.setMargins(0, dp(10), 0, 0);
            row.addView(status, slp);
            addView(row);
        }
    }

    private void renderReflection() {
        clearContent();
        
        content.addView(compactWeekSpinner("Woche auswählen", selectedWeek, pos -> {
            selectedWeek = pos;
            renderReflection();
        }));

        LinearLayout form = card();
        form.addView(label("Woche " + (selectedWeek + 1) + " reflektieren"));
        String[] labels = {"Fokus für die Woche", "Wins / Was lief gut?", "Blocker / Was war schwierig?", "Anpassung für nächste Woche"};
        EditText[] fields = new EditText[4];
        for (int i = 0; i < 4; i++) {
            form.addView(label(labels[i]));
            EditText e = edit(data.reflections[selectedWeek][i], labels[i]);
            e.setMinLines(2);
            e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
            fields[i] = e;
            form.addView(e);
        }
        Button save = primaryButton("Reflexion speichern");
        save.setOnClickListener(v -> {
            for (int i = 0; i < 4; i++) data.reflections[selectedWeek][i] = fields[i].getText().toString();
            saveData();
            toast("Reflexion gespeichert");
        });
        form.addView(save);
        addView(form);
    }

    private void renderTribe() {
        clearContent();

        if (!data.syncEnabled) {
            LinearLayout off = card();
            off.addView(label("Sync ist noch nicht aktiv"));
            off.addView(smallText("Aktiviere den Tribe Sync über Setup bearbeiten. Danach sehen alle mit demselben Gruppen-Code die gemeinsame Übersicht."));
            Button open = primaryButton("Sync einrichten");
            open.setOnClickListener(v -> showSettings());
            off.addView(open);
            addView(off);
            return;
        }

        if (tribeRegistration == null || !sanitizedGroupCode().equals(listeningGroup)) {
            ensureSignedInAndSync(false);
        }

        if (tribeMembers.isEmpty()) {
            LinearLayout empty = card();
            empty.addView(label("Noch keine Gruppendaten sichtbar"));
            empty.addView(smallText("Die App synchronisiert automatisch beim Start und ungefähr alle 30 Sekunden. Zieh die Liste nach unten, um manuell zu aktualisieren."));
            addView(empty);
            return;
        }

        ArrayList<TribeMember> sortedMembers = new ArrayList<>(tribeMembers);
        Collections.sort(sortedMembers, (a, b) -> {
            if (b.weekPercent != a.weekPercent) return b.weekPercent - a.weekPercent;
            if (b.streak != a.streak) return b.streak - a.streak;
            return a.displayName.compareToIgnoreCase(b.displayName);
        });

        int rank = 1;
        for (TribeMember m : sortedMembers) {
            int accent = tribeAccentColor(m.displayName);
            LinearLayout member = card();
            LinearLayout top = new LinearLayout(this);
            top.setOrientation(LinearLayout.HORIZONTAL);
            top.setGravity(Gravity.CENTER_VERTICAL);
            TextView rankBadge = pillText("#" + rank, accent);
            top.addView(rankBadge);
            TextView avatar = initialCircle(m.displayName, accent);
            LinearLayout.LayoutParams avlp = new LinearLayout.LayoutParams(dp(48), dp(48));
            avlp.setMargins(dp(10), 0, 0, 0);
            top.addView(avatar, avlp);
            LinearLayout nameBox = new LinearLayout(this);
            nameBox.setOrientation(LinearLayout.VERTICAL);
            nameBox.setPadding(dp(12), 0, 0, 0);
            nameBox.addView(label(m.displayName));
            nameBox.addView(smallText("Aktualisiert: " + timeAgo(m.updatedAtClient)));
            top.addView(nameBox, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            TextView streakBadge = pillText(m.streak + " Tage", accent);
            top.addView(streakBadge);
            member.addView(top);

            LinearLayout stats = new LinearLayout(this);
            stats.setOrientation(LinearLayout.HORIZONTAL);
            stats.setPadding(0, dp(12), 0, 0);
            stats.addView(metricPill("Heute", m.todayDone + " / " + m.todayDenom), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            stats.addView(space(dp(8)), new LinearLayout.LayoutParams(dp(8), 1));
            stats.addView(metricPill("Woche", m.weekPercent + "%"), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            stats.addView(space(dp(8)), new LinearLayout.LayoutParams(dp(8), 1));
            stats.addView(metricPill("Gesamt", m.overallPercent + "%"), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            member.addView(stats);
            ProgressBar tribeProgress = progressBar(100, m.weekPercent, accent);
            LinearLayout.LayoutParams tplp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(8));
            tplp.setMargins(0, dp(12), 0, 0);
            member.addView(tribeProgress, tplp);
            LinearLayout chipRow = new LinearLayout(this);
            chipRow.setOrientation(LinearLayout.HORIZONTAL);
            chipRow.setPadding(0, dp(12), 0, 0);
            chipRow.addView(pillText("Wochenziele " + m.weekGoals + " / " + m.activeHabits, accent));
            if (m.details != null && !m.details.trim().isEmpty()) {
                LinearLayout.LayoutParams chipLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                chipLp.setMargins(dp(8), 0, 0, 0);
                chipRow.addView(pillText(m.details, Color.rgb(86, 97, 110)), chipLp);
            }
            member.addView(chipRow);
            addView(member);
            rank++;
        }
    }

    private void renderChat() {
        clearContent();
        if (chatComposerView != null) {
            try { root.removeView(chatComposerView); } catch (Exception ignored) { }
            chatComposerView = null;
        }

        if (!data.syncEnabled) {
            LinearLayout off = card();
            off.addView(label("Chat ist noch nicht aktiv"));
            off.addView(smallText("Aktiviere den Tribe Sync über Setup bearbeiten. Der Chat nutzt denselben Gruppen-Code wie der Tribe-Reiter."));
            Button open = primaryButton("Sync einrichten");
            open.setOnClickListener(v -> showSettings());
            off.addView(open);
            addView(off);
            return;
        }

        content.setPadding(content.getPaddingLeft(), content.getPaddingTop(), content.getPaddingRight(), dp(112));

        if (chatRegistration == null || !sanitizedGroupCode().equals(listeningChatGroup)) {
            ensureSignedInAndSync(false);
            startChatListener();
        }

        if (chatMessages.isEmpty()) {
            LinearLayout empty = card();
            empty.addView(label("Noch keine Nachrichten"));
            empty.addView(smallText("Schreib die erste Nachricht. Alle mit demselben Gruppen-Code sehen sie hier."));
            addView(empty);
        } else {
            for (ChatMessage msg : chatMessages) {
                boolean mine = auth != null && auth.getCurrentUser() != null && auth.getCurrentUser().getUid().equals(msg.userId);
                LinearLayout outer = new LinearLayout(this);
                outer.setOrientation(LinearLayout.VERTICAL);
                outer.setGravity(mine ? Gravity.END : Gravity.START);
                LinearLayout.LayoutParams outerLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                outerLp.setMargins(0, 0, 0, dp(10));
                outer.setLayoutParams(outerLp);

                LinearLayout bubble = new LinearLayout(this);
                bubble.setOrientation(LinearLayout.VERTICAL);
                bubble.setPadding(dp(14), dp(10), dp(14), dp(10));
                bubble.setBackground(chatBubbleBackground(mine));
                LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(dp(290), ViewGroup.LayoutParams.WRAP_CONTENT);
                bubble.setLayoutParams(blp);

                TextView sender = smallCaps((mine ? "Du" : msg.displayName) + " · " + timeAgo(msg.createdAtClient));
                bubble.addView(sender);
                TextView body = new TextView(this);
                body.setText(msg.text);
                body.setTextColor(ink);
                body.setTextSize(15);
                body.setPadding(0, dp(5), 0, 0);
                bubble.addView(body);
                outer.addView(bubble);
                addView(outer);
            }
        }

        addChatComposer();
        if (mainScroll != null) mainScroll.post(() -> mainScroll.fullScroll(View.FOCUS_DOWN));
    }

    private void addChatComposer() {
        if (chatComposerView != null) {
            try { root.removeView(chatComposerView); } catch (Exception ignored) { }
            chatComposerView = null;
        }

        LinearLayout composer = new LinearLayout(this);
        composer.setOrientation(LinearLayout.HORIZONTAL);
        composer.setGravity(Gravity.CENTER_VERTICAL);
        composer.setPadding(dp(12), dp(10), dp(12), dp(10));
        composer.setBackground(chatComposerBackground());
        composer.setElevation(dp(8));

        EditText messageField = edit("", "Nachricht");
        messageField.setSingleLine(false);
        messageField.setMinLines(1);
        messageField.setMaxLines(4);
        messageField.setBackground(chatInputBackground());
        messageField.setPadding(dp(14), dp(10), dp(14), dp(10));
        LinearLayout.LayoutParams inputLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        composer.addView(messageField, inputLp);

        Button send = new Button(this);
        send.setText("➤");
        send.setAllCaps(false);
        send.setTextColor(Color.WHITE);
        send.setTextSize(18);
        send.setTypeface(Typeface.DEFAULT_BOLD);
        send.setBackground(round(green, dp(22)));
        LinearLayout.LayoutParams sendLp = new LinearLayout.LayoutParams(dp(46), dp(46));
        sendLp.setMargins(dp(10), 0, 0, 0);
        composer.addView(send, sendLp);

        send.setOnClickListener(v -> {
            String msg = messageField.getText().toString().trim();
            if (msg.isEmpty()) return;
            sendChatMessage(msg);
            messageField.setText("");
        });

        FrameLayout.LayoutParams flp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        flp.gravity = Gravity.BOTTOM;
        flp.setMargins(0, 0, 0, 0);
        root.addView(composer, flp);
        chatComposerView = composer;
    }

    private void renderSettings() {
        clearContent();
        setupVisibleHabitCount = clamp(Math.max(2, activeHabitCount()), 2, HABITS);

        renderSetupFields(true, true);

        LinearLayout menu = card();
        menu.addView(label("Daten & Zurücksetzen"));
        menu.addView(smallText("Export, Import und Zurücksetzen der App. Änderungen im Setup werden automatisch gespeichert, sobald du die Ansicht verlässt."));

        Button export = neutralButton("Daten exportieren");
        export.setOnClickListener(v -> {
            autosaveSetupDraft(true);
            exportJson();
        });
        menu.addView(export);

        Button imp = neutralButton("Daten importieren");
        imp.setOnClickListener(v -> {
            autosaveSetupDraft(true);
            importJson();
        });
        menu.addView(imp);

        Button reset = dangerButton("App zurücksetzen");
        reset.setOnClickListener(v -> confirmResetApp());
        menu.addView(reset);

        addView(menu);

        LinearLayout info = card();
        info.addView(label("Status-Legende"));
        info.addView(smallText("✓ = geschafft · ✗ = nicht geschafft · – = bewusst ausgelassen/neutral · leer = noch nicht eingetragen"));
        info.addView(smallText("Quoten zählen nur ✓ und ✗. – und leere Felder bleiben neutral."));
        addView(info);
    }

    private void confirmResetApp() {
        new AlertDialog.Builder(this)
                .setTitle("App wirklich zurücksetzen?")
                .setMessage("Alle lokalen Challenge-Daten werden gelöscht. Dieser Schritt kann nicht rückgängig gemacht werden.")
                .setNegativeButton("Abbrechen", null)
                .setPositiveButton("Zurücksetzen", (dialog, which) -> {
                    stopTribeListener();
                    stopChatListener();
                    data = new HabitData();
                    saveData();
                    toast("App zurückgesetzt");
                    showSetup(false);
                })
                .show();
    }

    private Spinner privacySpinner(int selected) {
        Spinner spinner = new Spinner(this);
        String[] items = new String[]{"Nur Fortschritt anzeigen", "Habit-Details für heute anzeigen"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, items);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setSelection(clamp(selected, 0, items.length - 1));
        return spinner;
    }

    private Spinner targetSpinner(int selected) {
        Spinner spinner = new Spinner(this);
        String[] items = new String[]{"0  ▾", "1  ▾", "2  ▾", "3  ▾", "4  ▾", "5  ▾", "6  ▾", "7  ▾"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, items);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        int safeSelected = clamp(selected, 0, 7);
        spinner.setSelection(safeSelected);
        spinner.setBackground(inputBackground());
        spinner.setPadding(dp(10), 0, dp(8), 0);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(78), dp(38));
        lp.setMargins(0, dp(3), 0, dp(4));
        spinner.setLayoutParams(lp);
        return spinner;
    }

    private View compactWeekSpinner(String labelText, int initial, final WeekSelection callback) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams boxLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        boxLp.setMargins(0, 0, 0, dp(12));
        box.setLayoutParams(boxLp);

        Spinner spinner = new Spinner(this);
        String[] items = new String[WEEKS];
        for (int i = 0; i < WEEKS; i++) items[i] = "Woche " + (i + 1);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, items) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                TextView view = (TextView) super.getView(position, convertView, parent);
                view.setText("Woche auswählen  ▾");
                view.setTextColor(ink);
                view.setTextSize(15);
                return view;
            }
        };
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setSelection(initial);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            boolean first = true;

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (first) {
                    first = false;
                    return;
                }
                callback.onSelect(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) { }
        });
        spinner.setBackground(inputBackground());
        spinner.setPadding(dp(10), 0, dp(10), 0);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(dp(166), dp(40));
        slp.setMargins(0, dp(2), 0, 0);
        spinner.setLayoutParams(slp);
        box.addView(spinner);
        return box;
    }

    private View weekSpinner(String labelText, int initial, final WeekSelection callback) {
        LinearLayout box = card();
        box.addView(label(labelText));
        Spinner spinner = new Spinner(this);
        String[] items = new String[WEEKS];
        for (int i = 0; i < WEEKS; i++) items[i] = "Woche " + (i + 1);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, items);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setSelection(initial);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            boolean first = true;

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (first) {
                    first = false;
                    return;
                }
                callback.onSelect(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) { }
        });
        spinner.setBackground(inputBackground());
        spinner.setPadding(dp(10), 0, dp(10), 0);
        box.addView(spinner);
        return box;
    }

    private interface WeekSelection { void onSelect(int week); }
    private interface AfterDatePicked { void onDone(); }

    private void pickStartDate(AfterDatePicked afterDatePicked) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(data.startDateMillis);
        DatePickerDialog dlg = new DatePickerDialog(this, (view, year, month, dayOfMonth) -> {
            Calendar chosen = Calendar.getInstance();
            chosen.set(Calendar.YEAR, year);
            chosen.set(Calendar.MONTH, month);
            chosen.set(Calendar.DAY_OF_MONTH, dayOfMonth);
            chosen.set(Calendar.HOUR_OF_DAY, 0);
            chosen.set(Calendar.MINUTE, 0);
            chosen.set(Calendar.SECOND, 0);
            chosen.set(Calendar.MILLISECOND, 0);
            data.startDateMillis = chosen.getTimeInMillis();
            saveData();
            toast("Startdatum gespeichert");
            afterDatePicked.onDone();
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH));
        dlg.show();
    }

    private void exportJson() {
        saveData();
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/json");
        intent.putExtra(Intent.EXTRA_TITLE, "endorphine_tribe_10w_export.json");
        startActivityForResult(intent, REQ_EXPORT);
    }

    private void importJson() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/json");
        startActivityForResult(intent, REQ_IMPORT);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent resultData) {
        super.onActivityResult(requestCode, resultCode, resultData);
        if (resultCode != RESULT_OK || resultData == null || resultData.getData() == null) return;
        Uri uri = resultData.getData();
        try {
            if (requestCode == REQ_EXPORT) {
                try (OutputStream os = getContentResolver().openOutputStream(uri)) {
                    if (os != null) os.write(data.toJson().toString(2).getBytes(StandardCharsets.UTF_8));
                }
                toast("Export gespeichert");
            } else if (requestCode == REQ_IMPORT) {
                String json = readUri(uri);
                data = HabitData.fromJson(json);
                saveData();
                selectedWeek = getCurrentWeek();
                toast("Import erfolgreich");
                if (!data.configured || activeHabitCount() == 0) showSetup(false);
                else showMainSection(SECTION_OVERVIEW);
            }
        } catch (Exception e) {
            toast("Fehler: " + e.getMessage());
        }
    }

    private String readUri(Uri uri) throws Exception {
        StringBuilder sb = new StringBuilder();
        try (InputStream is = getContentResolver().openInputStream(uri);
             BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) sb.append(line).append('\n');
        }
        return sb.toString();
    }

    private void sendChatMessage(String message) {
        if (!data.syncEnabled || firestore == null || auth == null) {
            toast("Chat-Sync nicht bereit.");
            return;
        }
        if (auth.getCurrentUser() == null) {
            ensureSignedInAndSync(false);
            toast("Sync wird vorbereitet. Bitte gleich nochmal senden.");
            return;
        }
        String group = sanitizedGroupCode();
        if (group.isEmpty()) {
            toast("Gruppen-Code fehlt.");
            return;
        }
        Map<String, Object> payload = new HashMap<>();
        payload.put("userId", auth.getCurrentUser().getUid());
        payload.put("displayName", safe(data.displayName, "Unbenannt"));
        payload.put("text", message);
        payload.put("createdAtClient", System.currentTimeMillis());
        payload.put("createdAt", FieldValue.serverTimestamp());
        firestore.collection("challenges")
                .document(group)
                .collection("messages")
                .add(payload)
                .addOnSuccessListener(unused -> startChatListener())
                .addOnFailureListener(e -> toast("Chat-Fehler: " + e.getMessage()));
    }

    private void startChatListener() {
        if (firestore == null || !data.syncEnabled || sanitizedGroupCode().isEmpty()) return;
        String group = sanitizedGroupCode();
        if (group.equals(listeningChatGroup) && chatRegistration != null) return;
        stopChatListener();
        listeningChatGroup = group;
        chatRegistration = firestore.collection("challenges")
                .document(group)
                .collection("messages")
                .orderBy("createdAtClient")
                .limit(80)
                .addSnapshotListener((snapshot, e) -> {
                    if (e != null) {
                        if (SECTION_CHAT.equals(currentSection)) toast("Chat-Update Fehler: " + e.getMessage());
                        return;
                    }
                    chatMessages.clear();
                    if (snapshot != null) {
                        for (QueryDocumentSnapshot doc : snapshot) {
                            chatMessages.add(ChatMessage.from(doc));
                        }
                    }
                    if (SECTION_CHAT.equals(currentSection)) renderChat();
                });
    }

    private void stopChatListener() {
        if (chatRegistration != null) {
            chatRegistration.remove();
            chatRegistration = null;
        }
        listeningChatGroup = "";
        chatMessages.clear();
    }

    private void setupFirebase() {
        try {
            String projectId = getString(R.string.firebase_project_id).trim();
            String appId = getString(R.string.firebase_application_id).trim();
            String apiKey = getString(R.string.firebase_api_key).trim();
            if (projectId.startsWith("PASTE_") || appId.startsWith("PASTE_") || apiKey.startsWith("PASTE_") || projectId.isEmpty() || appId.isEmpty() || apiKey.isEmpty()) {
                firebaseStatus = "Firebase-Konfiguration fehlt";
                return;
            }
            if (FirebaseApp.getApps(this).isEmpty()) {
                FirebaseOptions options = new FirebaseOptions.Builder()
                        .setProjectId(projectId)
                        .setApplicationId(appId)
                        .setApiKey(apiKey)
                        .build();
                FirebaseApp.initializeApp(this, options);
            }
            auth = FirebaseAuth.getInstance();
            firestore = FirebaseFirestore.getInstance();
            firebaseStatus = "Firebase bereit";
        } catch (Exception e) {
            firebaseStatus = "Firebase-Fehler: " + e.getMessage();
        }
    }

    private void ensureSignedInAndSync(boolean showToast) {
        if (!data.syncEnabled) return;
        if (firestore == null || auth == null) {
            firebaseStatus = "Firebase nicht verbunden";
            if (showToast) toast(firebaseStatus);
            return;
        }
        if (sanitizedGroupCode().isEmpty() || data.displayName.trim().isEmpty()) {
            firebaseStatus = "Name oder Gruppen-Code fehlt";
            if (showToast) toast(firebaseStatus);
            return;
        }
        FirebaseUser current = auth.getCurrentUser();
        if (current != null) {
            pushOwnData(showToast);
            startTribeListener();
            if (SECTION_CHAT.equals(currentSection)) startChatListener();
            return;
        }
        firebaseStatus = "Anonyme Anmeldung läuft…";
        auth.signInAnonymously()
                .addOnSuccessListener(result -> {
                    firebaseStatus = "Angemeldet · Sync aktiv";
                    pushOwnData(showToast);
                    startTribeListener();
                    if (SECTION_CHAT.equals(currentSection)) startChatListener();
                })
                .addOnFailureListener(e -> {
                    firebaseStatus = "Login fehlgeschlagen: " + e.getMessage();
                    if (showToast) toast(firebaseStatus);
                    if (SECTION_TRIBE.equals(currentSection)) renderTribe();
                });
    }

    private void pushOwnData(boolean showToast) {
        if (firestore == null || auth == null || auth.getCurrentUser() == null || !data.syncEnabled) return;
        String group = sanitizedGroupCode();
        if (group.isEmpty()) return;
        int today = dayIndexForToday();
        int week = getCurrentWeek();
        Map<String, Object> payload = new HashMap<>();
        payload.put("displayName", safe(data.displayName, "Unbenannt"));
        payload.put("groupCode", group);
        payload.put("updatedAt", FieldValue.serverTimestamp());
        payload.put("updatedAtClient", System.currentTimeMillis());
        payload.put("todayDone", dayDone(today));
        payload.put("todayDenom", dayDenom(today));
        payload.put("weekPercent", percentInt(weekDone(week), weekDenom(week)));
        payload.put("overallPercent", percentInt(totalDone(), totalDenom()));
        payload.put("streak", getStreak());
        payload.put("weekGoals", weekGoalsReached(week));
        payload.put("activeHabits", activeHabitCount());
        payload.put("privacyMode", data.privacyMode);
        payload.put("appVersion", 3);

        if (data.privacyMode == 1) {
            List<Map<String, Object>> details = new ArrayList<>();
            for (int h = 0; h < HABITS; h++) {
                if (!isHabitActive(h)) continue;
                Map<String, Object> item = new HashMap<>();
                item.put("name", data.habitNames[h]);
                item.put("state", data.states[today][h]);
                item.put("stateText", stateText(data.states[today][h]));
                details.add(item);
            }
            payload.put("todayDetails", details);
        }

        firestore.collection("challenges")
                .document(group)
                .collection("participants")
                .document(auth.getCurrentUser().getUid())
                .set(payload)
                .addOnSuccessListener(unused -> {
                    firebaseStatus = "Synchronisiert";
                    if (showToast) toast("Synchronisiert");
                    if (SECTION_TRIBE.equals(currentSection)) renderTribe();
                })
                .addOnFailureListener(e -> {
                    firebaseStatus = "Sync-Fehler: " + e.getMessage();
                    if (showToast) toast(firebaseStatus);
                    if (SECTION_TRIBE.equals(currentSection)) renderTribe();
                });
    }

    private void startTribeListener() {
        if (firestore == null || !data.syncEnabled || sanitizedGroupCode().isEmpty()) return;
        String group = sanitizedGroupCode();
        if (group.equals(listeningGroup) && tribeRegistration != null) return;
        stopTribeListener();
        listeningGroup = group;
        tribeRegistration = firestore.collection("challenges")
                .document(group)
                .collection("participants")
                .addSnapshotListener((snapshot, e) -> {
                    if (e != null) {
                        firebaseStatus = "Live-Update Fehler: " + e.getMessage();
                        if (SECTION_TRIBE.equals(currentSection)) renderTribe();
                        return;
                    }
                    tribeMembers.clear();
                    if (snapshot != null) {
                        for (QueryDocumentSnapshot doc : snapshot) {
                            tribeMembers.add(TribeMember.from(doc));
                        }
                    }
                    firebaseStatus = "Live verbunden";
                    if (SECTION_TRIBE.equals(currentSection)) renderTribe();
                });
    }

    private void stopTribeListener() {
        if (tribeRegistration != null) {
            tribeRegistration.remove();
            tribeRegistration = null;
        }
        listeningGroup = "";
        tribeMembers.clear();
    }

    private String sanitizedGroupCode() {
        if (data == null || data.groupCode == null) return "";
        return data.groupCode.trim().toLowerCase(Locale.ROOT).replace("/", "-");
    }

    private String timeAgo(long timestamp) {
        if (timestamp <= 0) return "unbekannt";
        long diff = Math.max(0, System.currentTimeMillis() - timestamp);
        long minutes = diff / 60000L;
        if (minutes < 1) return "gerade eben";
        if (minutes < 60) return "vor " + minutes + " min";
        long hours = minutes / 60;
        if (hours < 24) return "vor " + hours + " h";
        long days = hours / 24;
        return "vor " + days + " Tagen";
    }

    private void saveData() {
        prefs.edit().putString("data", data.toJson().toString()).apply();
        if (data != null && data.configured && data.syncEnabled) {
            ensureSignedInAndSync(false);
        }
    }

    private int activeHabitCount() {
        int count = 0;
        for (int i = 0; i < HABITS; i++) if (isHabitActive(i)) count++;
        return count;
    }

    private boolean isHabitActive(int h) {
        return data.habitNames[h] != null && !data.habitNames[h].trim().isEmpty();
    }

    private int dayDone(int d) {
        int n = 0;
        for (int h = 0; h < HABITS; h++) if (isHabitActive(h) && data.states[d][h] == 1) n++;
        return n;
    }

    private int dayDenom(int d) {
        int n = 0;
        for (int h = 0; h < HABITS; h++) if (isHabitActive(h) && (data.states[d][h] == 1 || data.states[d][h] == 2)) n++;
        return n;
    }

    private int habitWeekDone(int w, int h) {
        int n = 0;
        for (int d = w * 7; d < w * 7 + 7; d++) if (data.states[d][h] == 1) n++;
        return n;
    }

    private int habitWeekDenom(int w, int h) {
        int n = 0;
        for (int d = w * 7; d < w * 7 + 7; d++) if (data.states[d][h] == 1 || data.states[d][h] == 2) n++;
        return n;
    }

    private boolean habitWeekFullyRated(int w, int h) {
        for (int d = w * 7; d < w * 7 + 7; d++) {
            if (data.states[d][h] == 0) return false;
        }
        return true;
    }

    private boolean habitWeekAllX(int w, int h) {
        for (int d = w * 7; d < w * 7 + 7; d++) {
            if (data.states[d][h] != 2) return false;
        }
        return true;
    }

    private int weekDone(int w) {
        int n = 0;
        for (int d = w * 7; d < w * 7 + 7; d++) n += dayDone(d);
        return n;
    }

    private int weekDenom(int w) {
        int n = 0;
        for (int d = w * 7; d < w * 7 + 7; d++) n += dayDenom(d);
        return n;
    }

    private int weekGoalsReached(int w) {
        int n = 0;
        for (int h = 0; h < HABITS; h++) {
            if (!isHabitActive(h)) continue;
            if (data.targets[h] <= 0 || habitWeekDone(w, h) >= data.targets[h]) n++;
        }
        return n;
    }

    private int totalDone() {
        int n = 0;
        for (int d = 0; d < DAYS; d++) n += dayDone(d);
        return n;
    }

    private int totalDenom() {
        int n = 0;
        for (int d = 0; d < DAYS; d++) n += dayDenom(d);
        return n;
    }

    private int getStreak() {
        int today = dayIndexForToday();
        int streak = 0;
        for (int d = today; d >= 0; d--) {
            int denom = dayDenom(d);
            if (denom == 0) break;
            if (dayDone(d) == denom) streak++;
            else break;
        }
        return streak;
    }

    private int dayIndexForToday() {
        long diff = todayMidnight() - data.startDateMillis;
        int day = (int) (diff / (24L * 60L * 60L * 1000L));
        return clamp(day, 0, DAYS - 1);
    }

    private int getCurrentWeek() {
        return clamp(dayIndexForToday() / 7, 0, WEEKS - 1);
    }

    private long getDateForDay(int day) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(data.startDateMillis);
        c.add(Calendar.DAY_OF_YEAR, day);
        return c.getTimeInMillis();
    }

    private String formatDate(long millis) {
        return dateFormat.format(millis);
    }

    private static long todayMidnight() {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c.getTimeInMillis();
    }

    private String stateText(int state) {
        if (state == 1) return "✓";
        if (state == 2) return "✗";
        if (state == 3) return "–";
        return "leer";
    }

    private int stateColor(int state) {
        if (state == 1) return green;
        if (state == 2) return red;
        if (state == 3) return yellow;
        return Color.rgb(130, 136, 144);
    }

    private String percentText(int done, int denom) {
        if (denom <= 0) return "–";
        return Math.round((done * 100f) / denom) + "%";
    }

    private int percentInt(int done, int denom) {
        if (denom <= 0) return 0;
        return Math.round((done * 100f) / denom);
    }

    private LinearLayout card() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(18), dp(18), dp(18), dp(18));
        l.setBackground(cardBackground());
        l.setElevation(dp(4));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, dp(12));
        l.setLayoutParams(lp);
        return l;
    }

    private LinearLayout heroCard() {
        LinearLayout l = card();
        l.setBackground(heroBackground());
        return l;
    }

    private GradientDrawable cardBackground() {
        GradientDrawable gd = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{Color.rgb(27, 31, 38), Color.rgb(19, 22, 28)});
        gd.setCornerRadius(dp(28));
        gd.setStroke(dp(1), Color.argb(48, 255, 255, 255));
        return gd;
    }

    private GradientDrawable heroBackground() {
        GradientDrawable gd = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(31, 45, 61), Color.rgb(18, 24, 33)});
        gd.setCornerRadius(dp(32));
        gd.setStroke(dp(1), Color.argb(78, 205, 223, 255));
        return gd;
    }

    private GradientDrawable subCardBackground() {
        GradientDrawable gd = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{Color.rgb(34, 38, 46), Color.rgb(28, 32, 39)});
        gd.setCornerRadius(dp(22));
        gd.setStroke(dp(1), Color.argb(34, 255, 255, 255));
        return gd;
    }

    private GradientDrawable chatComposerBackground() {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(Color.TRANSPARENT);
        gd.setStroke(0, Color.TRANSPARENT);
        return gd;
    }

    private GradientDrawable chatInputBackground() {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(Color.rgb(30, 35, 42));
        gd.setCornerRadius(dp(22));
        gd.setStroke(dp(1), Color.argb(65, 255, 255, 255));
        return gd;
    }

    private GradientDrawable chatBubbleBackground(boolean mine) {
        GradientDrawable gd = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                mine
                        ? new int[]{Color.rgb(44, 86, 63), Color.rgb(34, 68, 50)}
                        : new int[]{Color.rgb(31, 35, 42), Color.rgb(27, 31, 37)});
        gd.setCornerRadius(dp(22));
        gd.setStroke(dp(1), Color.argb(mine ? 90 : 45, 255, 255, 255));
        return gd;
    }

    private GradientDrawable headerBackground() {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(Color.argb(138, 10, 12, 15));
        gd.setCornerRadius(0);
        gd.setStroke(0, Color.TRANSPARENT);
        return gd;
    }

    private GradientDrawable edgeFadeLeft() {
        GradientDrawable gd = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{Color.argb(95, 10, 12, 15), Color.argb(0, 10, 12, 15)});
        return gd;
    }

    private GradientDrawable edgeFadeRight() {
        GradientDrawable gd = new GradientDrawable(GradientDrawable.Orientation.RIGHT_LEFT,
                new int[]{Color.argb(95, 10, 12, 15), Color.argb(0, 10, 12, 15)});
        return gd;
    }

    private GradientDrawable tabBackground(boolean active) {
        GradientDrawable gd;
        if (active) {
            gd = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                    new int[]{Color.rgb(88, 175, 123), Color.rgb(63, 144, 99)});
            gd.setCornerRadius(dp(22));
            gd.setStroke(dp(1), Color.argb(110, 230, 255, 236));
        } else {
            gd = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                    new int[]{Color.argb(40, 255, 255, 255), Color.argb(24, 255, 255, 255)});
            gd.setCornerRadius(dp(20));
            gd.setStroke(dp(1), Color.argb(24, 255, 255, 255));
        }
        return gd;
    }

    private GradientDrawable round(int color, int radius) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(color);
        gd.setCornerRadius(radius);
        gd.setStroke(dp(1), Color.argb(80, 255, 255, 255));
        return gd;
    }

    private GradientDrawable inputBackground() {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(Color.rgb(28, 32, 39));
        gd.setCornerRadius(dp(16));
        gd.setStroke(dp(1), Color.rgb(61, 68, 78));
        return gd;
    }

    private int dayHeatColor(int day) {
        int rated = 0;
        int positive = 0;
        int negative = 0;
        int skipped = 0;
        for (int h = 0; h < HABITS; h++) {
            if (!isHabitActive(h)) continue;
            int s = data.states[day][h];
            if (s != 0) rated++;
            if (s == 1) positive++;
            else if (s == 2) negative++;
            else if (s == 3) skipped++;
        }
        if (rated == 0) return Color.rgb(72, 78, 86);
        if (positive == 0 && negative > 0 && skipped == 0) return red;
        if (positive > 0 && negative == 0) return green;
        return yellow;
    }

    private TextView circleStat(String value, String subtitle) {
        TextView t = new TextView(this);
        t.setText(value + "\n" + subtitle);
        t.setGravity(Gravity.CENTER);
        t.setTextColor(Color.WHITE);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setTextSize(17);
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(Color.argb(36, 255, 255, 255));
        gd.setShape(GradientDrawable.OVAL);
        gd.setStroke(dp(2), Color.argb(110, 210, 240, 225));
        t.setBackground(gd);
        t.setWidth(dp(94));
        t.setHeight(dp(94));
        return t;
    }

    private interface StateSelection { void onSelect(int state); }

    private LinearLayout stateSelector(int current, StateSelection callback) {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.HORIZONTAL);
        wrap.addView(selectorChip("✓", current == 1, green, () -> callback.onSelect(1)));
        LinearLayout.LayoutParams sp1 = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        sp1.setMargins(dp(6), 0, 0, 0);
        wrap.addView(selectorChip("✗", current == 2, red, () -> callback.onSelect(2)), sp1);
        LinearLayout.LayoutParams sp2 = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        sp2.setMargins(dp(6), 0, 0, 0);
        wrap.addView(selectorChip("–", current == 3, yellow, () -> callback.onSelect(3)), sp2);
        return wrap;
    }

    private TextView selectorChip(String label, boolean active, int activeColor, Runnable action) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setGravity(Gravity.CENTER);
        t.setTextColor(Color.WHITE);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setTextSize(15);
        GradientDrawable gd = new GradientDrawable();
        gd.setCornerRadius(dp(16));
        gd.setColor(active ? activeColor : Color.rgb(55, 61, 69));
        gd.setStroke(dp(1), active ? Color.argb(120, 255, 255, 255) : Color.argb(55, 255, 255, 255));
        t.setBackground(gd);
        t.setPadding(dp(12), dp(8), dp(12), dp(8));
        t.setMinWidth(dp(42));
        t.setOnClickListener(v -> action.run());
        return t;
    }

    private ProgressBar progressBar(int max, int progress, int color) {
        ProgressBar pb = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        pb.setMax(max);
        pb.setProgress(progress);
        GradientDrawable bgDrawable = new GradientDrawable();
        bgDrawable.setColor(Color.rgb(41, 46, 52));
        bgDrawable.setCornerRadius(dp(999));
        GradientDrawable progressDrawable = new GradientDrawable();
        progressDrawable.setColor(color);
        progressDrawable.setCornerRadius(dp(999));
        ClipDrawable clip = new ClipDrawable(progressDrawable, Gravity.START, ClipDrawable.HORIZONTAL);
        LayerDrawable layer = new LayerDrawable(new android.graphics.drawable.Drawable[]{bgDrawable, clip});
        layer.setId(0, android.R.id.background);
        layer.setId(1, android.R.id.progress);
        pb.setProgressDrawable(layer);
        pb.setMinHeight(dp(8));
        return pb;
    }

    private TextView smallCaps(String s) {
        TextView t = new TextView(this);
        t.setText(s.toUpperCase(Locale.ROOT));
        t.setTextColor(Color.rgb(171, 196, 226));
        t.setTextSize(11);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private TextView bigValue(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(ink);
        t.setTextSize(26);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private LinearLayout metricPill(String title, String value) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(12), dp(12), dp(12), dp(12));
        l.setBackground(subCardBackground());
        TextView top = new TextView(this);
        top.setText(title);
        top.setTextColor(muted);
        top.setTextSize(12);
        l.addView(top);
        TextView bottom = new TextView(this);
        bottom.setText(value);
        bottom.setTextColor(ink);
        bottom.setTypeface(Typeface.DEFAULT_BOLD);
        bottom.setTextSize(18);
        bottom.setPadding(0, dp(4), 0, 0);
        l.addView(bottom);
        return l;
    }

    private TextView pillText(String s, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(Color.WHITE);
        t.setTextSize(12);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(dp(11), dp(6), dp(11), dp(6));
        t.setBackground(round(color, dp(16)));
        return t;
    }

    private Button chipButton(String textValue, int color) {
        Button b = new Button(this);
        b.setText(textValue);
        b.setAllCaps(false);
        b.setTextSize(13);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextColor(Color.WHITE);
        b.setBackground(round(color, dp(19)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(82), dp(40));
        b.setLayoutParams(lp);
        return b;
    }

    private int tribeAccentColor(String name) {
        int[] palette = new int[]{
                Color.rgb(90, 170, 255),
                Color.rgb(110, 196, 117),
                Color.rgb(255, 159, 90),
                Color.rgb(192, 126, 255),
                Color.rgb(255, 111, 145),
                Color.rgb(88, 210, 198),
                Color.rgb(232, 196, 92),
                Color.rgb(255, 122, 122)
        };
        String key = name == null ? "" : name.trim().toLowerCase(Locale.ROOT);
        int idx = Math.abs(key.hashCode()) % palette.length;
        return palette[idx];
    }

    private TextView initialCircle(String name, int color) {
        TextView t = new TextView(this);
        String trimmed = name == null ? "?" : name.trim();
        String initial = trimmed.isEmpty() ? "?" : trimmed.substring(0, 1).toUpperCase(Locale.ROOT);
        t.setText(initial);
        t.setGravity(Gravity.CENTER);
        t.setTextColor(Color.WHITE);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setTextSize(17);
        t.setBackground(round(color, dp(22)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(44), dp(44));
        t.setLayoutParams(lp);
        return t;
    }

    private View space(int width) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(width, 1));
        return v;
    }

    private void addSectionTitle(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(24);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setTextColor(ink);
        t.setGravity(Gravity.START);
        t.setPadding(dp(2), dp(10), dp(2), dp(14));
        content.addView(t);
    }

    private void addSubsectionTitle(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(18);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setTextColor(Color.rgb(232, 236, 241));
        t.setGravity(Gravity.START);
        t.setPadding(dp(2), dp(6), dp(2), dp(10));
        content.addView(t);
    }

    private void animateSectionTransition() {
        if (content == null) return;
        for (int i = 0; i < content.getChildCount(); i++) {
            View child = content.getChildAt(i);
            child.setAlpha(0f);
            child.setTranslationY(dp(10));
            child.animate().alpha(1f).translationY(0f).setDuration(240).setStartDelay(Math.min(i * 22L, 120L)).start();
        }
    }

    private TextView label(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(ink);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setTextSize(17);
        t.setPadding(0, dp(4), 0, dp(4));
        return t;
    }

    private TextView smallText(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(muted);
        t.setTextSize(13);
        t.setPadding(0, dp(3), 0, dp(5));
        return t;
    }

    private TextView bigMetric(String key, String value) {
        TextView t = new TextView(this);
        t.setText(key + ": " + value);
        t.setTextColor(ink);
        t.setTextSize(16);
        t.setPadding(0, dp(4), 0, dp(4));
        return t;
    }

    private EditText edit(String value, String hint) {
        EditText e = new EditText(this);
        e.setText(value == null ? "" : value);
        e.setHint(hint);
        e.setTextSize(15);
        e.setSingleLine(false);
        e.setTextColor(ink);
        e.setHintTextColor(Color.rgb(135, 140, 148));
        e.setBackground(inputBackground());
        e.setPadding(dp(10), dp(8), dp(10), dp(8));
        return e;
    }

    private Button primaryButton(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextSize(15);
        b.setBackground(round(green, dp(20)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52));
        lp.setMargins(0, dp(8), 0, 0);
        b.setLayoutParams(lp);
        b.setElevation(dp(2));
        return b;
    }

    private Button neutralButton(String label) {
        Button b = primaryButton(label);
        b.setBackground(round(darkBlue, dp(18)));
        return b;
    }

    private Button dangerButton(String label) {
        Button b = primaryButton(label);
        b.setBackground(round(red, dp(18)));
        return b;
    }

    private Button softButton(String label) {
        Button b = primaryButton(label);
        b.setTextColor(ink);
        b.setBackground(round(Color.rgb(56, 61, 69), dp(18)));
        return b;
    }

    private void addView(View v) { content.addView(v); }
    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }
    private int parseInt(String s, int fallback) { try { return Integer.parseInt(s.trim()); } catch (Exception e) { return fallback; } }
    private int clamp(int v, int min, int max) { return Math.max(min, Math.min(max, v)); }
    private String safe(String s, String fallback) { return s == null || s.trim().isEmpty() ? fallback : s.trim(); }
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    public static class ChatMessage {
        String userId = "";
        String displayName = "Unbenannt";
        String text = "";
        long createdAtClient = 0;

        static ChatMessage from(DocumentSnapshot doc) {
            ChatMessage m = new ChatMessage();
            Object v = doc.get("userId"); if (v != null) m.userId = String.valueOf(v);
            v = doc.get("displayName"); if (v != null) m.displayName = String.valueOf(v);
            v = doc.get("text"); if (v != null) m.text = String.valueOf(v);
            Long l = doc.getLong("createdAtClient"); if (l != null) m.createdAtClient = l;
            return m;
        }
    }

    public static class TribeMember {
        String displayName = "Unbenannt";
        int todayDone = 0;
        int todayDenom = 0;
        int weekPercent = 0;
        int overallPercent = 0;
        int streak = 0;
        int weekGoals = 0;
        int activeHabits = 0;
        long updatedAtClient = 0;
        String details = "";

        static TribeMember from(DocumentSnapshot doc) {
            TribeMember m = new TribeMember();
            String name = doc.getString("displayName");
            if (name != null && !name.trim().isEmpty()) m.displayName = name.trim();
            Long l;
            l = doc.getLong("todayDone"); if (l != null) m.todayDone = l.intValue();
            l = doc.getLong("todayDenom"); if (l != null) m.todayDenom = l.intValue();
            l = doc.getLong("weekPercent"); if (l != null) m.weekPercent = l.intValue();
            l = doc.getLong("overallPercent"); if (l != null) m.overallPercent = l.intValue();
            l = doc.getLong("streak"); if (l != null) m.streak = l.intValue();
            l = doc.getLong("weekGoals"); if (l != null) m.weekGoals = l.intValue();
            l = doc.getLong("activeHabits"); if (l != null) m.activeHabits = l.intValue();
            l = doc.getLong("updatedAtClient"); if (l != null) m.updatedAtClient = l;
            Object detailsObj = doc.get("todayDetails");
            if (detailsObj instanceof List) {
                StringBuilder sb = new StringBuilder();
                for (Object obj : (List<?>) detailsObj) {
                    if (obj instanceof Map) {
                        Map<?, ?> map = (Map<?, ?>) obj;
                        Object n = map.get("name");
                        Object st = map.get("stateText");
                        if (n != null && st != null) {
                            if (sb.length() > 0) sb.append(" · ");
                            sb.append(n).append(": ").append(st);
                        }
                    }
                }
                m.details = sb.toString();
            }
            return m;
        }
    }

    public static class HabitData {
        boolean configured = false;
        boolean syncEnabled = false;
        String displayName = "";
        String groupCode = "";
        int privacyMode = 1;
        long startDateMillis = todayMidnight();
        String[] habitNames = new String[HABITS];
        int[] targets = new int[HABITS];
        int[][] states = new int[DAYS][HABITS];
        String[][] reflections = new String[WEEKS][4];

        HabitData() {
            for (int i = 0; i < HABITS; i++) {
                habitNames[i] = "";
                targets[i] = 5;
            }
            for (int w = 0; w < WEEKS; w++) for (int i = 0; i < 4; i++) reflections[w][i] = "";
        }

        JSONObject toJson() {
            JSONObject o = new JSONObject();
            try {
                o.put("version", 3);
                o.put("configured", configured);
                o.put("syncEnabled", syncEnabled);
                o.put("displayName", displayName);
                o.put("groupCode", groupCode);
                o.put("privacyMode", privacyMode);
                o.put("startDateMillis", startDateMillis);
                JSONArray h = new JSONArray();
                JSONArray t = new JSONArray();
                for (int i = 0; i < HABITS; i++) {
                    h.put(habitNames[i]);
                    t.put(targets[i]);
                }
                o.put("habitNames", h);
                o.put("targets", t);
                JSONArray days = new JSONArray();
                for (int d = 0; d < DAYS; d++) {
                    JSONArray row = new JSONArray();
                    for (int i = 0; i < HABITS; i++) row.put(states[d][i]);
                    days.put(row);
                }
                o.put("states", days);
                JSONArray ci = new JSONArray();
                for (int w = 0; w < WEEKS; w++) {
                    JSONArray row = new JSONArray();
                    for (int i = 0; i < 4; i++) row.put(reflections[w][i]);
                    ci.put(row);
                }
                o.put("reflections", ci);
            } catch (JSONException ignored) { }
            return o;
        }

        static HabitData fromJson(String json) {
            HabitData d = new HabitData();
            if (json == null || json.trim().isEmpty()) return d;
            try {
                JSONObject o = new JSONObject(json);
                d.configured = o.optBoolean("configured", false);
                d.syncEnabled = o.optBoolean("syncEnabled", false);
                d.displayName = o.optString("displayName", d.displayName);
                d.groupCode = o.optString("groupCode", d.groupCode);
                d.privacyMode = Math.max(0, Math.min(1, o.optInt("privacyMode", d.privacyMode)));
                d.startDateMillis = o.optLong("startDateMillis", d.startDateMillis);
                JSONArray h = o.optJSONArray("habitNames");
                if (h != null) for (int i = 0; i < Math.min(HABITS, h.length()); i++) d.habitNames[i] = h.optString(i, d.habitNames[i]);
                JSONArray t = o.optJSONArray("targets");
                if (t != null) for (int i = 0; i < Math.min(HABITS, t.length()); i++) d.targets[i] = Math.max(0, Math.min(7, t.optInt(i, d.targets[i])));
                JSONArray statesJson = o.optJSONArray("states");
                if (statesJson != null) {
                    for (int day = 0; day < Math.min(DAYS, statesJson.length()); day++) {
                        JSONArray row = statesJson.optJSONArray(day);
                        if (row == null) continue;
                        for (int i = 0; i < Math.min(HABITS, row.length()); i++) d.states[day][i] = Math.max(0, Math.min(3, row.optInt(i, 0)));
                    }
                }

                JSONArray refl = o.optJSONArray("reflections");
                if (refl == null) refl = o.optJSONArray("checkins");
                if (refl != null) {
                    for (int w = 0; w < Math.min(WEEKS, refl.length()); w++) {
                        JSONArray row = refl.optJSONArray(w);
                        if (row == null) continue;
                        for (int i = 0; i < Math.min(4, row.length()); i++) d.reflections[w][i] = row.optString(i, "");
                    }
                }

                if (!o.has("configured")) {
                    for (int i = 0; i < HABITS; i++) {
                        if (d.habitNames[i] != null && !d.habitNames[i].trim().isEmpty()) {
                            d.configured = true;
                            break;
                        }
                    }
                }
            } catch (JSONException ignored) { }
            return d;
        }
    }
}
