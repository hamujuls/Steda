# Trainingsplan Tracker Android Studio Projekt

Android Studio Projekt für den Gym-Tracker mit lokalem Fortschritts-Tracking.

## Neu in dieser Version

- In der Hauptansicht wird immer nur eine Übung mit allen Details angezeigt.
- Alle anderen Übungen erscheinen darunter nur als kompakte Karten mit Übungsnamen.
- Es wird kein Plan-Gewicht mehr in der Trainingsansicht angezeigt.
- Das Gewichtsfeld übernimmt den letzten geloggten Wert als Startwert.
- Zusätzliche kleinere Felder für Warm-up-Gewicht und Warm-up-WDH mit Werten vom letzten Training.
- Keine Done-Checkbox mehr oben in der Übungskarte.
- Der Abschluss-Button heißt jetzt **Fertig**.
- Beim Drücken auf **Fertig** blendet sich die aktuelle Übungskarte mit Animation aus und die nächste Übung wird groß angezeigt.
- Setup-Seite bleibt über das Zahnrad erreichbar.
- Übungen können im Setup weiterhin bearbeitet, gelöscht und hinzugefügt werden.
- Beim Wechsel zwischen Trainingstagen blenden alle Karten kurz aus und der neue Tag blendet weich ein.

## Öffnen

ZIP entpacken und den Ordner in Android Studio über **File → Open** öffnen.

## Build

In Android Studio: **Build → Build APK(s)** oder **Run** auf einem verbundenen Android Gerät.


Update: Zahlenkeyboard
- Gewicht, Warm-up-Gewicht, WDH und Warm-up-WDH öffnen jetzt mit numerischem Keyboard.
- Textfelder ohne Zahleneingabe bleiben normale Textfelder.


Update: Die unteren Buttons für Tag speichern/Heute/Timer wurden entfernt. Eingaben speichern automatisch; der Pausentimer bleibt über den Button in der aktiven Übung erreichbar.
